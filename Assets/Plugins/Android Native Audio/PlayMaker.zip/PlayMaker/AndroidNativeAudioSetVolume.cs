/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Sets the volume of a stream.")]
	public class AndroidNativeAudioSetVolume : FsmStateAction
	{
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the stream to change.")]
		public FsmInt streamID;

		[RequiredField]
		[Tooltip("The left volume to play at (0.0 - 1.0).  Set Right Volume to -1 to use this value for both.")]
		public FsmFloat leftVolume = 1;

		[RequiredField]
		[Tooltip("The right volume to play at (0.0 - 1.0).  Set to -1 to use Left Volume for both.")]
		public FsmFloat rightVolume = -1;

		public override void Reset()
		{
			streamID = null;
			leftVolume = 1;
			rightVolume = -1;
		}

		public override void OnEnter()
		{
			AndroidNativeAudio.setVolume(streamID.Value, leftVolume.Value, rightVolume.Value);
			Finish();
		}
	}
}

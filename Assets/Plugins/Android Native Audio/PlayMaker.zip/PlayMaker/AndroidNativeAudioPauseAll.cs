/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Pauses all streams.")]
	public class AndroidNativeAudioPauseAll : FsmStateAction
	{
		public override void OnEnter()
		{
			AndroidNativeAudio.pauseAll();
			Finish();
		}
	}
}

/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Resumes a paused stream.")]
	public class AndroidNativeAudioResume : FsmStateAction
	{
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the stream to resume.")]
		public FsmInt streamID;

		public override void Reset()
		{
			streamID = null;
		}

		public override void OnEnter()
		{
			AndroidNativeAudio.resume(streamID.Value);
			Finish();
		}
	}
}

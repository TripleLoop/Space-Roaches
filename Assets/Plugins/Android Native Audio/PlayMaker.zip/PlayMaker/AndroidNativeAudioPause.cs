/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Pauses a stream.")]
	public class AndroidNativeAudioPause : FsmStateAction
	{
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the stream to pause.")]
		public FsmInt streamID;

		public override void Reset()
		{
			streamID = null;
		}

		public override void OnEnter()
		{
			AndroidNativeAudio.pause(streamID.Value);
			Finish();
		}
	}
}

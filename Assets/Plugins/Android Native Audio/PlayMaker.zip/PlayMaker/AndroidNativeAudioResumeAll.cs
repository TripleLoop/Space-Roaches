/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Resumes all paused streams.")]
	public class AndroidNativeAudioResumeAll : FsmStateAction
	{
		public override void OnEnter()
		{
			AndroidNativeAudio.resumeAll();
			Finish();
		}
	}
}

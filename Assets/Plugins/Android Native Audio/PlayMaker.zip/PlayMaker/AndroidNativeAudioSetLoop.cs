/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Sets the loop of a stream.")]
	public class AndroidNativeAudioSetLoop : FsmStateAction
	{
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the stream to change.")]
		public FsmInt streamID;

		[RequiredField]
		[Tooltip("How many times to loop the sound.  A value of 0 will play once, -1 will loop until stopped.")]
		public FsmInt loop = 0;

		public override void Reset()
		{
			streamID = null;
			loop = 0;
		}

		public override void OnEnter()
		{
			AndroidNativeAudio.setLoop(streamID.Value, loop.Value);
			Finish();
		}
	}
}

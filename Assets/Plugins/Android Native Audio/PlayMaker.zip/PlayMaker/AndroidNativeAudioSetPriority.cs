/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Sets the priority of a stream.")]
	public class AndroidNativeAudioSetPriority : FsmStateAction
	{
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the stream to change.")]
		public FsmInt streamID;

		[RequiredField]
		[Tooltip("The priority of this stream.  If the number of simultaneously playing streams exceeds 'Max Playing' in 'Make Pool', higher priority streams will play and lower priority streams will not.")]
		public FsmInt priority = 1;

		public override void Reset()
		{
			streamID = null;
			priority = 1;
		}

		public override void OnEnter()
		{
			AndroidNativeAudio.setPriority(streamID.Value, priority.Value);
			Finish();
		}
	}
}

/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Loads a sound file.  Returns the sound ID.  Use 'Make Pool' before loading.")]
	public class AndroidNativeAudioLoad : FsmStateAction
	{
		[RequiredField]
        [Tooltip("The path to the sound file, relative to Assets\\StreamingAssets.")]
		public FsmString soundFile;
		
		[ActionSection("Returns")]
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the loaded sound.  Use with 'Play' and 'Unload'.")]
		public FsmInt soundID;

		public override void Reset()
		{
			soundFile = null;
			soundID = null;
		}

		public override void OnEnter()
		{
			soundID.Value = AndroidNativeAudio.load(soundFile.Value);
			Finish();
		}
	}
}
